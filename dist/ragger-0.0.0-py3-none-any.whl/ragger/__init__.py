"""A general-purpose RAG system and demo application."""

from .rag_system import RagSystem
